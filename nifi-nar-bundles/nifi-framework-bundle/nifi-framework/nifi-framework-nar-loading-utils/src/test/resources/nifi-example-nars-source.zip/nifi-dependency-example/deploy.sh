#!/bin/bash

find . -name *.nar -exec cp {} $1/lib/ \;
